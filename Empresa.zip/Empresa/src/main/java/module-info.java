module com.poo.empresa {
    requires javafx.controls;
    requires javafx.fxml;
            
        requires org.controlsfx.controls;
            requires com.dlsc.formsfx;
                    requires org.kordamp.bootstrapfx.core;
    //requires java.desktop;
    //requires rt;
    requires java.desktop;

    opens com.poo.empresa to javafx.fxml;
    //exports com.poo.empresa;
    exports com.poo.empresa.view;
    opens com.poo.empresa.view to javafx.fxml;
}