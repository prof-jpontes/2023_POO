package com.poo.empresa.model;

public class Diretor extends Gerente{

    private String departamento;
    public Diretor(double salario, String rg, String cpf, String nome, String cnt, String senha, String departamento) {
        super(salario, rg, cpf, nome, cnt, senha);
        this.departamento = departamento;

    }

    @Override
    public double getBonificacao() {
        return super.getBonificacao() + 2000.00;
    }

    @Override
    public String getRelatorio() {
        return super.getRelatorio() + "\nDepartamento: " + this.departamento;
    }
}
