package com.poo.empresa.view;

import com.poo.empresa.control.Controle;
import com.poo.empresa.model.Funcionario;
import com.poo.empresa.model.Gerente;

import javax.swing.*;
import java.awt.event.*;

public class TelaAutenticar extends JFrame {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JLabel JLB_login;
    private JLabel JLB_senha;
    private JTextField JTF_login;
    private JPasswordField JPF_senha;
    Controle controle;
    public TelaAutenticar(Controle controle) {
        this.controle = controle;
        setContentPane(contentPane);
        //setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setSize(500,400);
        setVisible(true);

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

        buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login = JTF_login.getText();
                String senha = JPF_senha.getText();
                JOptionPane.showMessageDialog(null,controle.autenticarFuncionario(login,senha));
                onCancel();
            }
        });

    }

    private void onOK() {
        // add your code here
        dispose();
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    public static void main(String[] args) {
        TelaAutenticar dialog = new TelaAutenticar(new Controle());
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }
}
