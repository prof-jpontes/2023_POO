package com.poo.empresa.view;

import com.poo.empresa.control.Controle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class TelaPrincipal extends JFrame {
    Controle controle;
    private JPanel JP_main;
    private JTextArea JTA_relatorioFuncionario;

    public TelaPrincipal () {

        controle = new Controle();
        JMenuBar menuBar = new JMenuBar();
        JTA_relatorioFuncionario = new JTextArea();

        setContentPane(JP_main);
        setTitle("Sistema");
        setSize(1000,800);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);
        setJMenuBar(menuBar);
        JMenu JM_funcionario = new JMenu("Funcionário");
        menuBar.add(JM_funcionario);
        JMenuItem JMI_cadastrar = new JMenuItem("Cadastrar");
        JMenuItem JMI_autenticar = new JMenuItem("Autenticar");
        JM_funcionario.add(JMI_cadastrar);
        JMI_autenticar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaAutenticar autenticar = new TelaAutenticar(controle);


            }
        });

        JMI_cadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CadastroFuncionario cadastrar = new CadastroFuncionario(controle);
            }
        });
        JMenuItem JMI_relatorio = new JMenuItem("Mostrar Relatorio");
        JM_funcionario.add(JMI_relatorio);
        JM_funcionario.add(JMI_autenticar);

        JMI_relatorio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(controle.relatorioFuncionarios());
                JTA_relatorioFuncionario.setText(controle.relatorioFuncionarios());
                System.out.println(controle.relatorioFuncionarios());
                JOptionPane.showMessageDialog(null, controle.relatorioFuncionarios());
            }
        });
    }

    public void mostrarRelatorio() {
        JTA_relatorioFuncionario.setVisible(true);
        JTA_relatorioFuncionario.setText(controle.relatorioFuncionarios());
        System.out.println(controle.relatorioFuncionarios());

    }

    public static void main(String[] args) {
        TelaPrincipal telaPrincipal = new TelaPrincipal();

    }
}
