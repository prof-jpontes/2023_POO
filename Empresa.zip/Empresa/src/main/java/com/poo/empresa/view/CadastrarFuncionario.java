package com.poo.empresa.view;

import com.poo.empresa.control.Controle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

public class CadastrarFuncionario extends JFrame {
    private JPanel JP_main;
    private JPanel JP_atributos;
    private JPanel JP_botoes;
    private JLabel JLB_nome;
    private JLabel JLB_cpf;
    private JLabel JLB_rg;
    private JLabel JLB_cnt;
    private JTextField JTF_nome;
    private JTextField JTF_cpf;
    private JTextField JTF_rg;
    private JTextField JTF_cnt;
    private JButton BTN_cancelar;
    private JButton BTN_limpar;
    private JButton BTN_cadastrar;

    Controle controle;

    public CadastrarFuncionario(Controle c){

        this.controle = c;
        setContentPane(JP_main);
        setTitle("Cadastrar novo funcionário");
        setSize(1000,800);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setVisible(true);

        BTN_cadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarFunc();
                System.out.println(controle.relatorioFuncionarios());
                limpar();
            }
        });


        BTN_limpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpar();
            }
        });
        BTN_cancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

    }

    public static void main(String[] args) {
        CadastrarFuncionario pe = new CadastrarFuncionario(new Controle());
    }

    public void cadastrarFunc() {
        controle.cadastrarFuncionario(JTF_rg.getText(),JTF_cpf.getText(),JTF_nome.getText(),JTF_cnt.getText());
    }

    public void limpar() {
        this.JTF_cnt.setText("");
        this.JTF_rg.setText("");
        this.JTF_nome.setText("");
        this.JTF_cpf.setText("");
    }

}
