package com.poo.empresa.model;

public class Funcionario {

    private double salario;
    private String rg;
    private String cpf;
    private String nome;
    private String cnt;

    public Funcionario(double salario, String rg, String cpf, String nome, String cnt) {
        this.salario = salario;
        this.rg = rg;
        this.cpf = cpf;
        this.nome = nome;
        this.cnt = cnt;
    }

    public Funcionario(String rg, String cpf, String nome, String cnt) {
        this.rg = rg;
        this.cpf = cpf;
        this.nome = nome;
        this.cnt = cnt;
        this.salario = 1500.00;
    }

    public double getSalario() {
        return salario;
    }


    public String getRelatorio() {
        String str = "\n";
        str += "Nome: "+this.nome;
        str += "\nRG: "+this.rg;
        str += "\nCPF: "+this.cpf;
        str += "\nCarteira de Trabalho: "+this.cnt;
        str += "\nSalario: "+this.salario;
        return str;
    }
}