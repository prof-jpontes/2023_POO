package com.poo.empresa.model;

public abstract class Funcionario {

    protected double salario;
    protected String rg;
    protected String cpf;
    protected String nome;
    protected String cnt;

    public Funcionario(double salario, String rg, String cpf, String nome, String cnt) {
        this.salario = salario;
        this.rg = rg;
        this.cpf = cpf;
        this.nome = nome;
        this.cnt = cnt;
    }


    public double getSalario() {
        return salario;
    }


    public String getRelatorio() {
        String str = "\n\n";
        str += "Nome: " + this.nome;
        str += "\nRG: " + this.rg;
        str += "\nCPF: " + this.cpf;
        str += "\nCarteira de Trabalho: " + this.cnt;
        str += "\nSalario: " + this.salario;
        str += "\nBonificação: " + this.getBonificacao();
        return str;
    }

    public abstract double getBonificacao();
}