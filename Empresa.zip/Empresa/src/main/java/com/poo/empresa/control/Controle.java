package com.poo.empresa.control;
import com.poo.empresa.model.Funcionario;

import java.util.HashMap;
import java.util.Map;

public class Controle {
    Map<String, Funcionario> mapaFuncionarios = new HashMap<String, Funcionario>();

    public void cadastrarFuncionario (String rg, String cpf, String nome, String cnt){
        mapaFuncionarios.put(cpf,new Funcionario(rg,cpf,nome,cnt));
    }

    public void cadastrarFuncionario (double salario ,String rg, String cpf, String nome, String cnt){
        mapaFuncionarios.put(cpf,new Funcionario(salario,rg,cpf,nome,cnt));
    }

    public String relatorioFuncionarios (){
        String str = "";
        for (Funcionario f: mapaFuncionarios.values()) {
            str += f.getRelatorio();
        }
        return str;
    }
}
