package com.poo.empresa.control;
import com.poo.empresa.model.*;

import java.util.HashMap;
import java.util.Map;

public class Controle {
    Map<String, Funcionario> mapaFuncionarios = new HashMap<String, Funcionario>();

    public void cadastrarGerente(double salario, String rg, String cpf, String nome, String cnt, String senha){
        mapaFuncionarios.put(cpf,new Gerente(salario,rg,cpf,nome,cnt,senha));
    }

    public void cadastrarTecnico(double salario, String rg, String cpf, String nome, String cnt){
        mapaFuncionarios.put(cpf, new Tecnico(salario, rg, cpf, nome, cnt));
    }

    public void cadastrarEngenheiro(double salario, String rg, String cpf, String nome, String cnt, String crea){
        mapaFuncionarios.put(cpf, new Engenheiro(salario, rg, cpf, nome, cnt, crea));
    }

    public void cadastrarDiretor(double salario, String rg, String cpf, String nome, String cnt, String senha, String departamento){
        mapaFuncionarios.put(cpf,new Diretor(salario,rg,cpf,nome,cnt,senha,departamento));
    }

    public String relatorioFuncionarios (){
        String str = "";
        for (Funcionario f: mapaFuncionarios.values()) {
            str += f.getRelatorio();
        }
        return str;
    }

    public String autenticarFuncionario(String login, String senha){
        Funcionario f = mapaFuncionarios.get(login);
        if (f instanceof Gerente){
            Gerente g = (Gerente)f;

            if (g.autenticar(login,senha)){
                return "Usuário autenticado!\n";
            }else{
                return "Login/Senha incorreto(s)!";
            }
        }
        return "Usuário não autenticável!";
        }


    public Map<String, Funcionario> getMapaFuncionarios() {
        return mapaFuncionarios;
    }
}
