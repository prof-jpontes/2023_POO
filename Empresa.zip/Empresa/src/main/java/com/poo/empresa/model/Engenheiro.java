package com.poo.empresa.model;

public class Engenheiro extends Funcionario{
    private String crea;
    public Engenheiro(double salario, String rg, String cpf, String nome, String cnt, String crea) {
        super(salario, rg, cpf, nome, cnt);
        this.crea = crea;
    }

    @Override
    public double getBonificacao() {
        return 10000.00;
    }
}
