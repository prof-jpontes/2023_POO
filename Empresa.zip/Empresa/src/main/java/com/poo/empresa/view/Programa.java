package com.poo.empresa.view;

import com.poo.empresa.control.Controle;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        Controle controle = new Controle();
        controle.cadastrarFuncionario(ler.nextLine(),ler.nextLine(),ler.nextLine(),ler.nextLine());
        controle.cadastrarFuncionario(Double.parseDouble(ler.nextLine()),ler.nextLine(),ler.nextLine(),ler.nextLine(),ler.nextLine());
        System.out.println(controle.relatorioFuncionarios());
    }
}
