package com.poo.empresa.model;

public class Tecnico extends Funcionario{

    public Tecnico(double salario, String rg, String cpf, String nome, String cnt) {
        super(salario, rg, cpf, nome, cnt);
    }

    @Override
    public double getBonificacao() {
        return this.salario * 0.1;
    }


}
