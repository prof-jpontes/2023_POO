package com.poo.empresa.view;

import com.poo.empresa.control.Controle;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CadastroFuncionario extends JFrame {
    private JPanel JP_main;
    private JPanel JP_atributos;
    private JPanel JP_botoes;
    private JLabel JLB_nome;
    private JLabel JLB_cpf;
    private JLabel JLB_rg;
    private JLabel JLB_cnt;
    private JTextField JTF_nome;
    private JTextField JTF_cpf;
    private JTextField JTF_rg;
    private JTextField JTF_cnt;
    private JButton BTN_cancelar;
    private JButton BTN_limpar;
    private JButton BTN_cadastrar;
    private JLabel JBL_cargo;
    private JCheckBox JCB_gerente;
    private JPasswordField JPF_senha;
    private JLabel JLB_senha;
    private JTextField JTF_salario;
    private JLabel JLB_salario;
    private JComboBox JCB_cargo;
    private JPanel JP_engenheiro;
    private JLabel JLB_crea;
    private JTextField JTF_crea;
    private JPanel JP_gerente;
    private JPanel JP_diretor;
    private JTextField JTF_departamento;
    private JLabel JLB_departamento;
    private JLabel JLB_senhaDiretor;
    private JPasswordField JPF_senhaDiretor;

    Controle controle;
    public CadastroFuncionario(Controle controle){
        this.controle = controle;
        this.tornarInvisivel();
        JCB_cargo.addItem("Técnico");
        JCB_cargo.addItem("Gerente");
        JCB_cargo.addItem("Diretor");
        JCB_cargo.addItem("Engenheiro");
        setContentPane(JP_main);
        setTitle("Cadastrar novo funcionário");
        setSize(1000,800);
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setVisible(true);

        JCB_cargo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tornarInvisivel();
                if (JCB_cargo.getSelectedItem().equals("Engenheiro")){
                    JP_engenheiro.setVisible(true);
                } else if(JCB_cargo.getSelectedItem().equals("Gerente")){
                    JP_gerente.setVisible(true);
                } else if(JCB_cargo.getSelectedItem().equals("Diretor")) {
                    JP_diretor.setVisible(true);
                }
            }
        });

        BTN_cadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cadastrarFunc();
                limpar();
            }
        });


        BTN_limpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpar();
            }
        });
        BTN_cancelar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        JLB_senha.setVisible(false);
        JPF_senha.setVisible(false);

        /*JCB_gerente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (JLB_senha.isVisible()){
                    JLB_senha.setVisible(false);
                    JPF_senha.setVisible(false);
                }else{
                    JLB_senha.setVisible(true);
                    JPF_senha.setVisible(true);
                }

            }
        });*/

    }

    public static void main(String[] args) {
        CadastroFuncionario pe = new CadastroFuncionario(new Controle());
    }

    public void cadastrarFunc() {

        if (JCB_cargo.getSelectedItem().equals("Gerente")){
            controle.cadastrarGerente(Double.parseDouble(JTF_salario.getText()), JTF_rg.getText(),JTF_cpf.getText(),JTF_nome.getText(),JTF_cnt.getText(), JPF_senha.getText());

        } else if (JCB_cargo.getSelectedItem().equals("Engenheiro")) {
            controle.cadastrarEngenheiro(Double.parseDouble(JTF_salario.getText()), JTF_rg.getText(),JTF_cpf.getText(),JTF_nome.getText(),JTF_cnt.getText(), JTF_crea.getText());

        } else if (JCB_cargo.getSelectedItem().equals("Diretor")) {
            controle.cadastrarDiretor(Double.parseDouble(JTF_salario.getText()), JTF_rg.getText(),JTF_cpf.getText(),JTF_nome.getText(),JTF_cnt.getText(), JPF_senhaDiretor.getText(), JTF_departamento.getText());

        } else if (JCB_cargo.getSelectedItem().equals("Técnico")){
            controle.cadastrarTecnico(Double.parseDouble(JTF_salario.getText()), JTF_rg.getText(),JTF_cpf.getText(),JTF_nome.getText(),JTF_cnt.getText());
        }

    }

    public void limpar() {
        this.JTF_cnt.setText("");
        this.JTF_rg.setText("");
        this.JTF_nome.setText("");
        this.JTF_cpf.setText("");
        this.JPF_senha.setText("");
    }

    public void tornarInvisivel(){
        JP_engenheiro.setVisible(false);
        JP_diretor.setVisible(false);
        JP_gerente.setVisible(false);
    }

}
