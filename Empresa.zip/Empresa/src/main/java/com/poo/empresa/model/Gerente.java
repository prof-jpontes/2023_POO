package com.poo.empresa.model;

public class Gerente extends Funcionario{

private String senha;

    public Gerente(double salario, String rg, String cpf, String nome, String cnt) {
        super(salario, rg, cpf, nome, cnt);
        this.senha = null;
    }

    public Gerente(String rg, String cpf, String nome, String cnt, String senha) {
        super(rg, cpf, nome, cnt);
        this.senha = senha;
    }

    public boolean autenticar (String chave, String senha){
        if (senha.equals(this.senha) && chave.equals(this.cpf)){
            return true;
        }
        return false;
    }
    @Override
    public String getRelatorio() {
        return super.getRelatorio()+"\nÉ um gerente!";
    }
}
